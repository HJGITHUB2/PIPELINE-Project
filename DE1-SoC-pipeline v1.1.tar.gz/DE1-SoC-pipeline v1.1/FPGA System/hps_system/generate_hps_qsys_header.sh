#!/bin/sh
sopc-create-header-files \
"$PWD/cnn_hps_system.sopcinfo" \
--single hps_0.h \
--module hps_0